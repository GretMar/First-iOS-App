//
//  LoginView.swift
//  First App
//
//  Created by Gretchen White on 9/18/23.
//

import SwiftUI

struct LoginView: View {
  @StateObject var viewModel: LoginViewModel
  var body: some View {
    VStack(spacing: 24) {
      Image("Logo")
        .resizable()
        .scaledToFit()
      VStack(alignment: .leading, spacing: 2) {
        Text("Username")
        TextField(
          "Username",
          text: $viewModel.username,
          prompt: Text("Enter username")
        )
          .textFieldStyle(.roundedBorder)
          .textInputAutocapitalization(.never)
      }
      VStack(alignment: .leading, spacing: 2) {
        Text("Password")
        SecureField(
          "Password",
          text: $viewModel.password,
          prompt: Text("Enter password")
        ).textFieldStyle(.roundedBorder)
      }
      Button {
        viewModel.login()
      } label: {
        Text("Login")
      }.disabled(viewModel.username == "" || viewModel.password == "")

    }.padding()
  }
}

struct LoginView_Preview: PreviewProvider {
  static var previews: some View {
    LoginView(viewModel: LoginViewModel())
  }
}
