//
//  LoginViewModel.swift
//  First App
//
//  Created by Gretchen White on 9/18/23.
//

import SwiftUI

struct Token: Codable {
  let token: String
}

class LoginViewModel: ObservableObject {
  @Published var username = ""
  @Published var password = ""
  
  func login() {
    Task {
      do {
        try await performLogin()
      } catch {
        print(error)
      }
    }
  }
  
  private func checkResponse(_ response: URLResponse) -> Bool {
    guard let httpResponse = response as? HTTPURLResponse else {
      return false
    }
    return httpResponse.statusCode == 200
  }
  
  private func performLogin() async throws {
    let (data, response) = try await URLSession.shared.data(for: try createRequest())
    guard checkResponse(response) else {
      return
    }
    let token: Token = try JSONDecoder().decode(Token.self, from: data)
    print(token)
  }
  
  private func createRequest() throws -> URLRequest {
    var request = URLRequest(url: URL(string: "https://staging.pestopaypoint.com/pos/v1/staff_users/sign_in")!)
    request.httpMethod = "POST"
    let params: [String: Any] = [
      "pos_v1_staff_user": [
        "username": username,
        "password": password
      ]
    ]
    request.httpBody = try JSONSerialization.data(withJSONObject: params)
    request.setValue("application/vnd.api+json", forHTTPHeaderField: "Content-Type")
    request.setValue("application/vnd.api+json", forHTTPHeaderField: "Accept")
    request.setValue("Bearer eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJiNDVhNmNkYS1lMjE1LTQ0NGQtOWZlYy0yZDRjNmQyNjdkZGUiLCJzdWIiOiI0NjYiLCJzY3AiOiJwb3NfdjFfc3RhZmZfdXNlciIsImF1ZCI6bnVsbCwiaWF0IjoxNjk1MDUxODIxLCJleHAiOjE2OTUwOTUwMjF9.U_9AXiqA5_24WVr_kfmEdMhmbDW_qTMeNo2JBue2guY", forHTTPHeaderField: "Authorization")
    return request
  }
}
