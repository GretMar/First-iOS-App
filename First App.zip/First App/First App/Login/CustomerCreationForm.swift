//
//  CustomerCreationForm.swift
//  PointOfSale
//
//  Created by Gretchen White on 9/25/23.
//  Copyright © 2023 The Pesto Group, Inc. All rights reserved.
//

import SwiftUI

struct CustomerCreationForm: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    CustomerCreationForm()
}
