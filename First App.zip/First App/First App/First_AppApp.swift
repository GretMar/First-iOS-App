//
//  First_AppApp.swift
//  First App
//
//  Created by Gretchen White on 9/7/23.
//

import SwiftUI

@main
struct First_AppApp: App {
  var body: some Scene {
    WindowGroup {
      ContentView()
    }
  }
}
